<!doctype html>
<html>
<head>
    
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>SurveyLite</title>
<link rel="stylesheet" type="text/css" href="css/fpage.css">

</head>

<body id="mainB">
<div id="p_guard">

<header>
<div class="container"><h1>SurveyLite</h1><nav><ul><li><a href="login.php" id="loginNav">LOGIN</a></li></ul></nav></div></header>



<section><div class="container"><div id="main_text">
<p><h2> Experience speed and better research without stress</h2></p>




<p>Construct your research questionnaire at ease with just a few steps</p>

<p>Share your research questionniare to as much as 5,000 people without printing</p>

<p>No special device required</p>


<ul>
<li>It's easy</li>
<li>It's fast</li>
<li>Its reliable</li>
<li>Data validity is guaranteed</li>
</ul>

<p><h2>Exolore more with our mobile app, it's available on Google Play Store and Apple Store. </h2></p>



</div>



<div id="form_area">
<form id="form" action="ua__reg__manager.php" method="post" enctype="multipart/form-data">

<p align="center" id="form_signuptxt_p"><h2 id="form_signuptxt">SIGN UP</h2></p>

<div class="field_txtlabel"><h5>First name</h5></div>
<p align="center"><label for="firstname"><input id="firstname" type="text" name="ua__firstname"  placeholder="First name" required></label></p>

<div class="field_txtlabel"><h5>Last name</h5></div>
<p align="center"><label for="lastname"><input id="lastname" type="text" name="ua__lastname" placeholder="Last name" required></label></p>

<div class="field_txtlabel"><h5>Email address</h5></div>
<p align="center"><label for="email"><input id="surname" type="email" name="ua__email" placeholder="Email address" required></label></p>


<div class="field_txtlabel"><h5>Password</h5></div>
<p align="center"><label for="password1"><input id="password1" type="password" name="ua__password1" placeholder="Enter Password" required></label></p>

<div class="field_txtlabel"><h5>Confirm password</h5></div>
<p align="center"><label for="password2"><input id="password2" type="password" name="ua__password2" placeholder="Confirm Password" required></label></p>

<p id="g_select">Gender:<select name="ua__gender">
<option value="0">Select</option>
<option value="male">Male</option>
<option value="female">Female</option>
</select>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Country:
<select name="ua__country" style="width:140px;">
<option value="0">Select</option>
<optgroup>A</optgroup>
<option value="Afghanistan">Afghanistan</option>
<option value="Albania">Albania</option>
<option value="Algeria">Algeria</option>
<option value="Andorra">Andorra</option>
<option value="Angola">Angola</option>
<option value="Antigua and Barbuda">Antigua and Barbuda</option>
<option value="Argentina">Argentina</option>
<option value="Armenia">Armenia</option>
<option value="Australia">Australia</option>
<option value="Austria">Austria</option>
<option value="Azerbaijan">Azerbaijan</option>
<optgroup>B</optgroup>
<option value="Bahamas">Bahamas</option>
<option value="Bahrain">Bahrain</option>
<option value="Bangladesh">Bangladesh</option>
<option value="Barbados">Barbados</option>
<option value="Belarus">Belarus</option>
<option value="Belgium">Belgium</option>
<option value="Belize">Belize</option>
<option value="Benin">Benin</option>
<option value="Bhutan">Bhutan</option>
<option value="Bolivia">Bolivia</option>
<option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
<option value="Botswana">Botswana</option>
<option value="Brazil">Brazil</option>
<option value="Brunei">Brunei</option>
<option value="Bulgaria">Bulgaria</option>
<option value="Burkina Faso">Burkina Faso</option>
<option value="Burundi">Burundi</option>
<optgroup>C</optgroup>
<option value="Cabo Verde">Cabo Verde</option>
<option value="Cambodia">Cambodia</option>
<option value="Cameroon">Cameroon</option>
<option value="Canada">Canada</option>
<option value="Central African Republic">Central African Republic</option>
<option value="Chad">Chad</option>
<option value="Chile">Chile</option>
<option value="China">China</option>
<option value="Colombia">Colombia</option>
<option value="Comoros">Comoros</option>
<option value="Democratic Republic of the Congo">DR Congo</option>
<option value="Republic of the Congo">Republic of the Congo</option>
<option value="Costa Rica">Costa Rica</option>
<option value="Cote d'Ivoire">Cote d'Ivoire</option>
<option value="Croatia">Croatia</option>
<option value="Cuba">Cuba</option>
<option value="Cyprus">Cyprus</option>
<option value="Czech Republic">Czech Republic</option>
<optgroup>D</optgroup>
<option value="Denmark">Denmark</option>
<option value="Djibouti">Djibouti</option>
<option value="Dominica">Dominica</option>
<option value="Dominican Republic">Dominican Republic</option>
<optgroup>E</optgroup>
<option value="Ecuador">Ecuador</option>
<option value="Egypt">Egypt</option>
<option value="El Salvador">El Salvador</option>
<option value="Equatorial Guinea">Equatorial Guinea</option>
<option value="Eritrea">Eritrea</option>
<option value="Estonia">Estonia</option>
<option value="Eswatini">Eswatini</option>
<option value="Ethiopia">Ethiopia</option>
<optgroup>F</optgroup>
<option value="Fiji">Fiji</option>
<option value="Finland">Finland</option>
<option value="France">France</option>
<optgroup>G</optgroup>
<option value="Gabon">Gabon</option>
<option value="Gambia">Gambia</option>
<option value="Georgia">Georgia</option>
<option value="Germany">Germany</option>
<option value="Ghana">Ghana</option>
<option value="Greece">Greece</option>
<option value="Grenada">Grenada</option>
<option value="Guatemala">Guatemala</option>
<option value="Guinea">Guinea</option>
<option value="Guinea-Bissau">Guinea-Bissau</option>
<option value="Guyana">Guyana</option>
<optgroup>H</optgroup>
<option value="Haiti">Haiti</option>
<option value="Honduras">Honduras</option>
<option value="Hungary">Hungary</option>
<optgroup>I</optgroup>
<option value="Iceland">Iceland</option>
<option value="India">India</option>
<option value="Indonesia">Indonesia</option>
<option value="Iran">Iran</option>
<option  value="Iraq">Iraq</option>
<option  value="Ireland">Ireland</option>
<option  value="Israel">Israel</option>
<option  value="Italy">Italy</option>
<optgroup>J</optgroup>
<option  value="Jamaica">Jamaica</option>
<option  value="Japan">Japan</option>
<option  value="Jordan">Jordan</option>
<optgroup>K</optgroup>
<option  value="Kazakhstan">Kazakhstan</option>
<option  value="Kenya">Kenya</option>
<option  value="Kiribati">Kiribati</option>
<option value="Kosovo">Kosovo</option>
<option value="Kuwait">Kuwait</option>
<option  value="Kyrgyzstan">Kyrgyzstan</option>
<optgroup>L</optgroup>
<option  value="Laos">Laos</option>
<option  value="Latvia">Latvia</option>
<option  value="Lebanon">Lebanon</option>
<option  value="Lesotho">Lesotho</option>
<option  value="Liberia">Liberia</option>
<option  value="Libya">Libya</option>
<option  value="Liechtenstein">Liechtenstein</option>
<option value="Lithuania">Lithuania</option>
<option value="Luxembourg">Luxembourg</option>
<optgroup>M</optgroup>
<option value="Macedonia">Macedonia</option>
<option value="Madagascar">Madagascar</option>
<option value="Malawi">Malawi</option>
<option value="Malaysia">Malaysia</option>
<option value="Maldives">Maldives</option>
<option value="Mali">Mali</option>
<option value="Malta">Malta</option>
<option value="Marshall Islands">Marshall Islands</option>
<option value="Mauritania">Mauritania</option>
<option value="Mauritius">Mauritius</option>
<option value="Mexico">Mexico</option>
<option value="Micronesia">Micronesia</option>
<option value="Moldova">Moldova</option>
<option value="Monaco">Monaco</option>
<option value="Mongolia">Mongolia</option>
<option value="Montenegro">Montenegro</option>
<option value="Morocco">Morocco</option>
<option value="Mozambique">Mozambique</option>
<option value="Myanmar">Myanmar</option>
<optgroup>N</optgroup>
<option value="Namibia">Namibia</option>
<option value="Nauru">Nauru</option>
<option value="Nepal">Nepal</option>
<option value="Netherlands">Netherlands</option>
<option value="New Zealand">New Zealand</option>
<option value="Nicaragua">Nicaragua</option>
<option value="Niger">Niger</option>
<option value="Nigeria">Nigeria</option>
<option value="North Korea">North Korea</option>
<option value="Norway">Norway</option>
<optgroup>O</optgroup>
<option value="Oman">Oman</option>
<optgroup>P</optgroup>
<option value="Pakistan">Pakistan</option>
<option value="Palau">Palau</option>
<option value="Palestine">Palestine</option>
<option value="Panama">Panama</option>
<option value="Papua New Guinea">Papua New Guinea</option>
<option value="Paraguay">Paraguay</option>
<option value="Peru">Peru</option>
<option value="Philippines">Philippines</option>
<option value="Poland">Poland</option>
<option value="Portugal">Portugal</option>

<optgroup>Q</optgroup>
<option value="Qatar">Qatar</option>
<optgroup>R</optgroup>
<option value="Romania">Romania</option>
<option value="Russia">Russia</option>
<option value="Rwanda">Rwanda</option>
<optgroup>S</optgroup>
<option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
<option value="Saint Lucia">Saint Lucia</option>
<option value="Saint Vincent and the Grenadines">Saint Vincent</option>
<option value="Samoa">Samoa</option>
<option value="San Marino">San Marino</option>
<option value="Sao Tome and Principe">Sao Tome and Principe</option>
<option value="Saudi Arabia">Saudi Arabia</option>
<option value="Senegal">Senegal</option>
<option value="Serbia">Serbia</option>
<option value="Seychelles">Seychelles</option>
<option  value="Sierra Leone">Sierra Leone</option>
<option value="Singapore">Singapore</option>
<option value="Slovakia">Slovakia</option>
<option value="Slovenia">Slovenia</option>
<option value="Solomon Islands">Solomon Islands</option>
<option value="Somalia">Somalia</option>
<option value="South Africa">South Africa</option>
<option value="South Korea">South Korea</option>
<option value="South Sudan">South Sudan</option>
<option value="Spain">Spain</option>
<option value="Sri Lanka">Sri Lanka</option>
<option value="Sudan">Sudan</option>
<option value="Suriname">Suriname</option>
<option value="Sweden">Sweden</option>
<option value="Switzerland">Switzerland</option>
<option value="Syria">Syria</option>
<optgroup>T</optgroup>
<option value="Taiwan">Taiwan</option>
<option value="Tajikistan">Tajikistan</option>
<option value="Tanzania">Tanzania</option>
<option value="Thailand">Thailand</option>
<option value="Timor-Leste">Timor-Leste</option>
<option value="Togo">Togo</option>
<option value="Tonga">Tonga</option>
<option value="Trinidad and Tobago">Trinidad and Tobago</option>
<option value="Tunisia">Tunisia</option>
<option value="Turkey">Turkey</option>
<option value="Turkmenistan">Turkmenistan</option>
<option value="Tuvalu">Tuvalu</option>
<optgroup>U</optgroup>
<option value="Uganda">Uganda</option>
<option value="Ukraine">Ukraine</option>
<option value="United Arab Emirates (UAE)">United Arab Emirates</option>
<option value="United Kingdom (UK)">United Kingdom (UK)</option>
<option value="United States of America (USA)">United States of America</option>
<option value="Uruguay">Uruguay</option>
<option value="Uzbekistan">Uzbekistan</option>
<optgroup>V</optgroup>
<option value="Vanuatu">Vanuatu</option>
<option value="Vatican City">Vatican City</option>
<option value="Venezuela">Venezuela</option>
<option value="Vietnam">Vietnam</option>
<optgroup>Y</optgroup>
<option value="Yemen">Yemen</option>
<optgroup>Z</optgroup>
<option value="Zambia">Zambia</option>
<option value="Zimbabwe">Zimbabwe</option>



</select>
</p>



<p align="center"><label for="submit"><input id="submit" type="submit" name="ua__reg__submit" value="Sign Up"></label></p>


<p align="center"><a href="login.php" id="acc_al-exist_link">I already have an account?</a></p>






</form>
</div>



  </div>
  </section>




  <footer><div class="container"><div id="cright"><p align="center"> &copy;Easy research 2018. All rights reserved.</p></div></div></footer>

</div>
</body>
</html>


<?php


include_once("msgOnSuccessfulRegAndEmailSent.php");


?>



